<?php

/*--------------------------------------------------------------
	
	Script Name    : Contents Maker
	Author         : FIRSTSTEP - Motohiro Tani
	Author URL     : https://www.1-firststep.com
	Create Date    : 2015/05/20
	Version        : 7.0
	Last Update    : 2020/06/27
	
--------------------------------------------------------------*/


error_reporting( E_ALL );
mb_internal_encoding( 'UTF-8' );




include( dirname(__FILE__) .'/class.contents-maker-display.php' );
$contents_maker_display = new Contents_Maker_Display();




if ( file_exists( dirname( __FILE__ ) .'/../addon/number/number.php' ) ) {
	include( dirname( __FILE__ ) .'/../addon/number/number.php' );
}




$contents_maker_display->get_news( false );




?>