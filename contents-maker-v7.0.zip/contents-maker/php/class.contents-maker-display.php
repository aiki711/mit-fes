<?php


require_once( dirname( __FILE__ ) .'/class.contents-maker.php' );




class Contents_Maker_Display Extends Contents_Maker {
	
	// public construct
	public function __construct() {
		
		parent::__construct();
		
	}
	
	
	
	
	// public get_number
	public function get_number() {
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/number/get-number.php' ) ) {
			include( dirname( __FILE__ ) .'/../addon/number/get-number.php' );
		}
		
	}
	
}

?>