<?php

class Contents_Maker_Js {
	
	// PHP public construct
	public function __construct() {
		
		header( 'Content-Type: application/javascript' );
		
		
		echo <<<EOM

/*--------------------------------------------------------------
	
	Script Name    : Contents Maker
	Author         : FIRSTSTEP - Motohiro Tani
	Author URL     : https://www.1-firststep.com
	Create Date    : 2015/05/20
	Version        : 7.0
	Last Update    : 2020/06/27
	
--------------------------------------------------------------*/


function contents_maker() {
	
	var news   = document.getElementById( 'news' );
	var js     = document.getElementById( 'contents-maker-js' );
	var href   = js.getAttribute( 'src' ).replace( /js\/contents-maker-js\.php/gi, 'php/index.php' );
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/number/query-number.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/number/query-number.js' );
		}
		
		
		
		
		echo <<<EOM

	
	
	var xhr = new XMLHttpRequest();
	xhr.open( 'GET', href, true );
	
	xhr.onreadystatechange = function() {
		if ( xhr.readyState === 4 && xhr.status === 200 ) {
			news.insertAdjacentHTML( 'beforeend', xhr.responseText );
		}
	}
	
	xhr.send( null );
	
}




if ( document.readyState == 'loading' ) {
	document.addEventListener( 'DOMContentLoaded', function() {
		contents_maker();
	}, false );
} else {
	contents_maker();
}
EOM;
		
	}
	
}

?>