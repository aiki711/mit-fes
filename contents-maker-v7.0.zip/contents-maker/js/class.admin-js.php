<?php

class Contents_Maker_Admin_Js {
	
	// html tag addon property
	protected $html_tag       = 0;
	
	
	
	
	// public construct
	public function __construct() {
		
		include( dirname( __FILE__ ) .'/../php/config.php' );
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/html-tag/tag-config.php' ) ) {
			include( dirname( __FILE__ ) .'/../addon/html-tag/tag-config.php' );
			include( dirname( __FILE__ ) .'/../addon/html-tag/config-include.php' );
		}
		
		
		header( 'Content-Type: application/javascript' );
		
		
		echo <<<EOM
(function( $ ) {
	
	// global variable init
	var cm_token    = '';
	var scroll_flag = false;
	
	
	
	
	// function slice_method
	function slice_method( el ) {
		var dt      = el.parents( 'dd' ).prev( 'dt' );
		var dt_name = dt.html().replace( /<span>.*<\/span>/gi, '' );
		dt_name     = dt_name.replace( /^<span\s.*<\/span>/gi, '' );
		dt_name     = dt_name.replace( /<br>|<br \/>/gi, '' );
		return dt_name;
	}
	
	
	
	
	// function error_span
	function error_span( e, dt, comment, bool ) {
		if ( bool === true ) {
			e.parents( 'dd' ).find( 'span.error-blank' ).text( dt + 'が' + comment + 'されていません' );
		} else {
			e.parents( 'dd' ).find( 'span.error-blank' ).text( '' );
		}
	}
	
	
	
	
	// function compare_method
	function compare_method( s, e ) {
		if ( s > e ) {
			return e;
		} else {
			return s;
		}
	}
	
	
	
	
	// function hidden_append
	function hidden_append( name, value, element ){
		
		$( '<input />' )
			.attr({
				type: 'hidden',
				id: name,
				name: name,
				value: value
			})
			.appendTo( element );
		
	}
	
	
	
	
	// function pagetop_click
	function pagetop_click() {
		
		$( 'html, body' ).animate({
			scrollTop: 0
		}, 500 );
		
	}
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/file-change.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/file-change.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/sort/sortable-send.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/sort/sortable-send.js' );
		}
		
		
		
		
		echo <<<EOM

	
	
	
	
	// function new_click
	function new_click() {
		
		if ( $( 'form#contents-maker-edit-form' ).css( 'display' ) === 'block' ) {
			$( 'form#contents-maker-edit-form' ).fadeOut( 'fast', function() {
				$( 'form#contents-maker-form' ).fadeIn( 'fast' );
			});
		} else {
			$( 'form#contents-maker-form' ).slideDown( 'normal' );
		}
		
	}
	
	
	
	
	// function cancel_click
	function cancel_click() {
		
		$( 'form#contents-maker-form, form#contents-maker-edit-form' ).slideUp( 'normal' );
		
	}
	
	
	
	
	// function token_get
	function token_get() {
		
		$.ajax({
			type: 'POST',
			url: $( 'form#contents-maker-form' ).attr( 'action' ),
			cache: false,
			dataType: 'text',
			data: 'token-get=true&javascript_action=true',
		})
		.done(function( res ) {
			var response = res.split( ',' );
			if ( response[0] === 'token_success' ) {
				cm_token = response[1];
				setTimeout(function() {
					token_get();
				}, 900000 );
			} else {
				alert( 'トークンの取得に失敗しました。' );
			}
		})
		.fail(function( res ) {
			alert( 'Ajax通信が失敗しました。\\nページの再読み込みをしてからもう一度お試しください。' );
		});
		
	}
	
	
	
	
	// function logout_click
	function logout_click() {
		
		if ( window.confirm( 'ログアウトしますか？' ) ) {
			
			$.ajax({
				type: 'POST',
				url: $( 'form#contents-maker-form' ).attr( 'action' ),
				cache: false,
				dataType: 'text',
				data: 'logout=true&javascript_action=true',
			})
			.done(function( res ) {
				var response = res.split( ',' );
				if ( response[0] === 'logout_success' ) {
					window.location.href = response[1];
				} else {
					window.alert( 'ログアウトが失敗しました。' );
					window.location.reload();
				}
			})
			.fail(function( res ) {
				window.alert( 'Ajax通信が失敗しました。\\nページの再読み込みをしてからもう一度お試しください。' );
			});
			
		}
		
	}
	
	
	
	
	// function edit_click
	function edit_click() {
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/exist-reset.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/exist-reset.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/edit-date.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/edit-date.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/status/radio-checked.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/status/radio-checked.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/edit-contents.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/edit-contents.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/exist-image.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/exist-image.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/edit-scroll.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/edit-scroll.js' );
		}
		
		
		
		
		echo <<<EOM

		
	}
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/reset-click.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/reset-click.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/status/public-private-js.php' ) ) {
			include( dirname( __FILE__ ) .'/../addon/status/public-private-js.php' );
		}
		
		
		
		
		echo <<<EOM

	
	
	
	
	// function delete_click
	function delete_click() {
		
		var delete_number = $( this ).attr( 'data-delete' );
		
		if ( window.confirm( '削除してもよろしいですか？' ) ) {
			
			$( '<div>' )
				.addClass( 'loading-layer' )
				.appendTo( 'body' )
				.append( '<span class="loading"></span>' );
				
			setTimeout(function(){
				
				$.ajax({
					type: 'POST',
					url: $( 'form#contents-maker-form' ).attr( 'action' ),
					cache: false,
					dataType: 'text',
					data: 'delete-number=' + delete_number + '&javascript_action=true&token=' + cm_token,
				})
				.done(function( res ) {
					$( 'div.loading-layer, span.loading' ).remove();
					var response = res.split( ',' );
					if ( response[0] === 'delete_success' ) {
						window.alert( '削除が完了しました。' );
						window.location.href = response[1];
					} else {
						window.alert( '削除が失敗しました。' );
						window.location.reload();
					}
				})
				.fail(function( res ) {
					$( 'div.loading-layer, span.loading' ).remove();
					window.alert( 'Ajax通信が失敗しました。\\nページの再読み込みをしてからもう一度お試しください。' );
				});
					
			}, 1000 );
			
		}
		
	}
	
	
	
	
	// function write_click
	function write_click() {
		
		var form         = '';
		var date         = '';
		var attach       = '';
		var contents     = '';
		var status       = '';
		var label        = '';
		
		var error        = 0;
		var scroll_point = $( 'body' ).height();
		
		
		if ( $( this ).attr( 'id' ) === 'write-button' ) {
			
			form     = $( 'form#contents-maker-form' );
			date     = form.find( 'input.date' );
			attach   = form.find( 'input.attachment' );
			contents = form.find( 'textarea.contents' );
			status   = form.find( 'input.status' );
			label    = '新規投稿';
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/edit-element.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/edit-element.js' );
		}
		
		
		
		
		echo <<<EOM

			
		}
		
		
		if ( $( '.required' ).find( date ).length ) {
			var element = $( '.required' ).find( date );
			var dt_name = slice_method( element );
			if ( element.val() === '' ) {
				error_span( element, dt_name, '入力', true );
				error++;
				scroll_point = compare_method( scroll_point, element.offset().top );
			} else {
				error_span( element, dt_name, '', false );
			}
		}
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/required-check.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/required-check.js' );
		}
		
		
		
		
		echo <<<EOM

		
		
		if ( $( '.required' ).find( contents ).length ) {
			var element = $( '.required' ).find( contents );
			var dt_name = slice_method( element );
			if ( element.val() === '' ) {
				error_span( element, dt_name, '入力', true );
				error++;
				scroll_point = compare_method( scroll_point, element.offset().top );
			} else {
				error_span( element, dt_name, '', false );
			}
		}
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/status/required-check.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/status/required-check.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/html-tag/url-check-js.php' ) ) {
			include( dirname( __FILE__ ) .'/../addon/html-tag/url-check-js.php' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/filetype-check.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/filetype-check.js' );
		}
		
		
		
		
		echo <<<EOM

		
		
		if ( error === 0 ) {
			if ( window.confirm( label + 'をしてもよろしいですか？' ) ) {
				
				hidden_append( 'javascript_action', 'true', form.find( 'p.submit' ) );
				hidden_append( 'token', cm_token, form.find( 'p.submit' ) );
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/ios-bugfix-1.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/ios-bugfix-1.js' );
		}
		
		
		
		
		echo <<<EOM

				
				$( '<div>' )
					.addClass( 'loading-layer' )
					.appendTo( 'body' )
					.append( '<span class="loading"></span>' );
				
				setTimeout(function(){
					
					var form_data = new FormData( form.get(0) );
					
					$.ajax({
						type: form.attr( 'method' ),
						url: form.attr( 'action' ),
						cache: false,
						dataType: 'html',
						data: form_data,
						contentType: false,
						processData: false,
					})
					.done(function( res ) {
						$( 'div.loading-layer, span.loading' ).remove();
						var response = res.split( ',' );
						if ( response[0] === 'write_success' ) {
							window.alert( label + 'が完了しました。' );
							window.location.reload();
						} else {
							$( 'input#javascript_action' ).remove();
							ios_bugfix();
							window.alert( label + 'が失敗しました。' );
						}
					})
					.fail(function( res ) {
						$( 'div.loading-layer, span.loading' ).remove();
						window.alert( 'Ajax通信が失敗しました。\\nページの再読み込みをしてからもう一度お試しください。' );
					});
					
				}, 1000 );
				
			}
		} else {
			$( 'html, body' ).animate({
				scrollTop: scroll_point - 70
			}, 500 );
		}
		
	}
	
	
	
	
	// function ios_bugfix
	function ios_bugfix() {
		
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/ios-bugfix-2.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/ios-bugfix-2.js' );
		}
		
		
		
		
		echo <<<EOM

	}
	
	
	
	
	// function label_insert
	function label_insert( cmf_dd, bool ) {
		
		for ( var i = 1; i < cmf_dd.length; i++ ) {
			if ( cmf_dd.eq(i).attr( 'class' ) === 'required' ) {
				$( '<span/>' )
					.text( '必須' )
					.addClass( 'required' )
					.prependTo( cmf_dd.eq(i).prev( 'dt' ) );
			} else {
				$( '<span/>' )
					.text( '任意' )
					.addClass( 'optional' )
					.prependTo( cmf_dd.eq(i).prev( 'dt' ) );
			}
			
			$( '<span/>' )
				.addClass( 'error-blank' )
				.appendTo( cmf_dd.eq(i) );
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/html-tag/span-url-js.php' ) ) {
			include( dirname( __FILE__ ) .'/../addon/html-tag/span-url-js.php' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/error-filetype.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/error-filetype.js' );
		}
		
		
		
		
		echo <<<EOM

		}
		
	}
	
	
	
	
	// DOM
	$( 'input' ).on( 'keydown', function( e ) {
		if ( ( e.which && e.which === 13 ) || ( e.keyCode && e.keyCode === 13 ) ) {
			return false;
		} else {
			return true;
		}
	});
	
	
	var cmf_dd = $( 'form#contents-maker-form dl dd' );
	label_insert( cmf_dd, false );
	
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/edit-dd.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/edit-dd.js' );
		}
		
		
		
		
		echo <<<EOM

	
	
	token_get();
	
	
	$( window ).on( 'scroll', function() {
		if ( 150  < $( window ).scrollTop() ) {
			if ( scroll_flag === false ) {
				scroll_flag = true;
				$( 'div#page-top' ).fadeIn( 'fast' );
			}
		} else {
			if ( scroll_flag === true ) {
				scroll_flag = false;
				$( 'div#page-top' ).fadeOut( 'fast' );
			}
		}
	});
	
	
	if ( ! ( $( 'div#information' ).find( 'dl' ).length ) ) {
		$( 'div#information' ).css({
			'border': 'none',
			'padding': '0',
			'box-shadow': 'none'
		});
	}
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/sort/sortable-method.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/sort/sortable-method.js' );
		}
		
		
		
		
		echo <<<EOM

	
	
	$( 'li#new div' ).on({
		
		'mouseenter': function() {
			if ( $( 'form#contents-maker-form' ).css( 'display' ) === 'block' ) {
				$( this ).css({
					'cursor': 'default',
					'color': 'inherit',
					'background': 'none'
				});
			} else {
				$( this ).css({
					'cursor': 'pointer',
					'color': '#106dff',
					'background': 'rgba( 0, 0, 0, 0.1 )'
				});
			}
		},
		
		'mouseleave': function() {
			$( this ).css({
				'cursor': 'default',
				'color': 'inherit',
				'background': 'none'
			});
		}
		
	});
	
	
	$( 'div#page-top' ).on( 'click', pagetop_click );
	
	$( 'li#new div' ).on( 'click', new_click );
	
	$( 'li#logout div' ).on( 'click', logout_click );
	
	$( 'span.cancel' ).on( 'click', cancel_click );
EOM;
		
		
		
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/span-reset.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/span-reset.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/attachment/input-change.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/attachment/input-change.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/edit/class-edit.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/edit/class-edit.js' );
		}
		
		if ( file_exists( dirname( __FILE__ ) .'/../addon/status/span-public.js' ) ) {
			include( dirname( __FILE__ ) .'/../addon/status/span-public.js' );
		}
		
		
		
		
		echo <<<EOM

	
	$( 'span.delete' ).on( 'click', delete_click );
	
	$( 'input#write-button, input#edit-button' ).on( 'click', write_click );
	
})( jQuery );
EOM;
		
	}
	
}

?>